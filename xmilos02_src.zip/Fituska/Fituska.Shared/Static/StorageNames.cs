﻿namespace Fituska.Shared.Static;

public static class StorageNames
{
    public const string Bearer = "bearer";
    public const string BearerToken = $"{Bearer}Token";
    public const string UserPhoto = "userPhoto";
}
