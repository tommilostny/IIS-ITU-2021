﻿namespace Fituska.Shared.Enums;

public enum VoteValue
{
    Downvote = -1, Upvote = 1 , Neutral = 0
}
