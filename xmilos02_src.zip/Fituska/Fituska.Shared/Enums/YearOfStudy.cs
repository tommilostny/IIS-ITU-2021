﻿namespace Fituska.Shared.Enums;

public enum YearOfStudy
{
    BIT1 = 1, BIT2, BIT3, MIT1, MIT2
}
