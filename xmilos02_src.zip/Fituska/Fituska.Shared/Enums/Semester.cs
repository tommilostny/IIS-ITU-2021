﻿namespace Fituska.Shared.Enums;

public enum Semester
{
    Winter, Summer
}
