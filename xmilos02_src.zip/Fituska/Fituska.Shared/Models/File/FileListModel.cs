﻿namespace Fituska.Shared.Models.File;

public record FileListModel : ModelBase
{
    public string Name { get; set; }
}
