﻿namespace Fituska.Shared.Models;

public interface IModel
{
    Guid Id { get; init; }
}