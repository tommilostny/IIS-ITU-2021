﻿namespace Fituska.Shared.Models.Search;

public class SearchAnswerModel
{
    public Guid QuestionId { get; set; }
    public string Text { get; set; }
}
