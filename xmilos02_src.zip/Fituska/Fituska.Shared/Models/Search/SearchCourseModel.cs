﻿namespace Fituska.Shared.Models.Search;

public class SearchCourseModel
{
    public string Name { get; set; }
    public string Shortcut { get; set; }
    public string Url { get; set; }
}
