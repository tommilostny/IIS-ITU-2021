﻿namespace Fituska.Shared.Models.Search;

public class SearchUserModel
{
    public string UserName { get; set; }
    public string? FirstName { get; set; }
    public string? LastName { get; set; }
}
