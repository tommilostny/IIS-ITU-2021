﻿global using Fituska.Shared.Models.CourseAttendance;
global using Fituska.Shared.Models.Question;
global using Fituska.Shared.Static;
global using System.Collections.Generic;
global using System.ComponentModel.DataAnnotations;
global using System.Linq;
