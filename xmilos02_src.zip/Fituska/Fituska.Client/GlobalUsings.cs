﻿global using Blazored.LocalStorage;
global using Fituska.Client.Providers;
global using Fituska.Client.Services;
global using Fituska.Shared.Static;
global using Microsoft.AspNetCore.Components;
global using Microsoft.AspNetCore.Components.Authorization;
global using System.Net.Http.Headers;
