﻿global using AutoMapper;
global using Fituska.DAL;
global using Fituska.DAL.Entities;
global using Fituska.DAL.Entities.Interfaces;
global using Microsoft.EntityFrameworkCore;
global using System.Linq;
