﻿namespace Fituska.DAL.Entities.Interfaces;

public interface IEntity
{
    public Guid Id { get; set; }
}
