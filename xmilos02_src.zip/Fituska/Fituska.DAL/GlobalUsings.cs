﻿global using Fituska.DAL.Entities;
global using Fituska.Shared.Enums;
global using Fituska.Shared.Static;
global using Nemesis.Essentials.Design;
