﻿namespace Fituska.DAL.Factories;

public interface IDbContextFactory
{
    FituskaDbContext Create();
}
